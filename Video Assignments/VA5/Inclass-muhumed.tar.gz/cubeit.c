#include "myutil.h"

int
cubeit(int x){
    return x * x * x;
}