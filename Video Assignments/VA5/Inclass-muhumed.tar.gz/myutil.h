#pragma once

#ifndef _MYUTIL_H
#define _MYUTIL_H

int squareit(int);
int cubeit(int);

#endif //_MYUTIL_H