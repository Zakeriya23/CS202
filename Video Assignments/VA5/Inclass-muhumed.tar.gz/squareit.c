#include "myutil.h"

int
squareit(int x){
    return x*x;
}