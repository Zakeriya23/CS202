#include <stdio.h>

//  gcc -Wall -o hello hello.c   --> compiles code 
//  ./hello --> runs code 

int main(void){

    printf("Hello cs201!!\n");
    return 0;
}